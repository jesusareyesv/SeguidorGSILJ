/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comunications;

/**
 *
 * @author jesus.reyes
 */
public interface IOBluetoothConstants {
    final static int TIMEOUT = 2000;//tiempo de espera
    final static int baudRate = 9600;//frecuencia de conexion
    //algunas variables ASCII
    final static int SPACE_ASCII = 32;
    final static int DASH_ASCII = 45;
    final static int NEW_LINE_ASCII = 10;
}
